******************************************************************
*    Installation of the printer driver package for Windows 10   *
******************************************************************

Double-click a DriverInstall.CMD file to start installation of a driver package.

Refer to the printer driver instruction manual of Windows 7,8,and 10 for the details about installation.

