DS-RX1 Printer Driver Version
   Windows XP    : V.1.1.3.0
   Windows Vista : V.1.1.3.0
   Windows 7     : V.1.1.3.0
   Windows 8     : V.1.1.3.0
   Windows 10    : V.1.1.3.0

Driver ICM Version    RX1_v2.icc

